#!/usr/bin/env python3
"""Synthetic schema-faithful offline fixture. Never reads an existing cache body."""
import pathlib,json,hashlib,gzip,base64,calendar,datetime,argparse
p=argparse.ArgumentParser();p.add_argument('--out',required=True);a=p.parse_args();out=pathlib.Path(a.out);out.mkdir(parents=True,exist_ok=True)
root=pathlib.Path(__file__).resolve().parents[1]
catalog=json.loads((root/'tong-sky/src/main/assets/asiana-regions.json').read_text())
codes=sorted({x['code'] for rows in catalog['regions'].values() for x in rows if x['code']!='ICN'})
encode=lambda x:json.dumps(x,ensure_ascii=False,separators=(',',':')).encode()
sha=lambda b:hashlib.sha256(b).hexdigest()
fields=['economyAward','premiumAward','prestigeAward','premiumUpgrade','prestigeUpgrade','firstCombined']
current='2026-10-29T00:00:00+09:00';previous='2026-10-28T00:00:00+09:00';success=int(datetime.datetime.fromisoformat(current).timestamp()*1000)
def snapshot(carrier,o,d,month,rev,index):
    y,m=map(int,month.split('-'));days=[]
    for day in range(1,calendar.monthrange(y,m)[1]+1):
        row={'date':f'{month}-{day:02}','status':'OBSERVED'}
        for fi,field in enumerate(fields):row[field]=bool((index+day+fi+rev)%5==0)
        if carrier=='OZ':
            n=2 if (index+day)%10<3 else 3
            row['flights']=[{'number':f'OZ{700+(index+j)%200}','departure':f'{7+j*4:02}:{(index+day+j)%60:02}','bookingClass':['X','I','P'][j%3]} for j in range(n)]
        days.append(row)
    clock=current if rev else previous
    return {'carrier':carrier,'origin':o,'destination':d,'month':month,'sourceUpdatedAt':clock,'collectedAt':clock,'dates':days}
metadata={'schema':1,'synthetic':True,'source':'Public airport catalog and aggregate dimensions only; no original cache body','documents':{}}
for carrier,count,prior,region in [('OZ',1194,911,'아시아나'),('KE',24,18,'유럽')]:
    records={};expected=[];daycount=flightcount=0
    pairs=[]
    usecodes=codes if carrier=='OZ' else ['CDG','LHR','FCO','FRA','AMS','PRG']
    for moff in range(10):
        y=2025+(10+moff)//12;m=(10+moff)%12+1;month=f'{y}-{m:02}'
        for code in usecodes:
            for o,d in [('ICN',code),(code,'ICN')]:pairs.append((o,d,month))
    assert len(pairs)>=count
    for index,(o,d,month) in enumerate(pairs[:count]):
        c=snapshot(carrier,o,d,month,1,index);v={'current':c,'success':success}
        prev=snapshot(carrier,o,d,month,0,index) if index<prior else None
        if prev is not None:v['previous']=prev
        key=f'{o}-{d}-{month}';records[key]=v
        expected.append({'key':key,'currentSha256':sha(encode(c)),'previousSha256':sha(encode(prev)) if prev is not None else None,'success':success})
        for snap in [c,prev]:
            if snap:
                daycount+=len(snap['dates']);flightcount+=sum(len(x.get('flights',[])) for x in snap['dates'])
    body={'schema':1,'origin':'ICN','region':region,'records':records}
    plain=encode(body);compressed=gzip.compress(plain,compresslevel=6,mtime=0)
    packed=encode({'encoding':'gzip-base64','data':base64.b64encode(compressed).decode()})
    gitsha=hashlib.sha1(b'blob '+str(len(packed)).encode()+b'\0'+packed).hexdigest()
    contents=encode({'sha':gitsha,'encoding':'base64','content':base64.b64encode(packed).decode()})
    (out/f'{carrier}-packed.json').write_bytes(packed);(out/f'{carrier}-contents.json').write_bytes(contents)
    (out/f'{carrier}-expected.json').write_bytes(encode(expected))
    metadata['documents'][carrier]={'records':count,'previous':prior,'snapshots':count+prior,'days':daycount,'flights':flightcount,'plainBytes':len(plain),'gzipBytes':len(compressed),'packedBytes':len(packed),'contentsBytes':len(contents),'packedSha256':sha(packed),'contentsSha256':sha(contents),'gitBlobSha':gitsha,'expectedSha256':sha(encode(expected))}
    print(carrier,json.dumps(metadata['documents'][carrier]))
(out/'fixture-manifest.json').write_text(json.dumps(metadata,indent=2,ensure_ascii=False)+'\n')
