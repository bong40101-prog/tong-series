#!/usr/bin/env python3
"""Validate exact low-memory offline native run; never infer live provider speed."""
import json,pathlib,re,sys
mode=sys.argv[1];root=pathlib.Path(sys.argv[2]);r=json.loads((root/'performance-device-report.json').read_text());log=(root/'logcat.txt').read_text(errors='replace');pid=r['pid'];filtered='\n'.join(line for line in log.splitlines() if re.search(r'\s'+str(pid)+r'\s',line))
assert mode in {'baseline135','candidate136'}
assert r['api']==33 and r['runtimeMaxHeapBytes']==192*1024*1024
assert not r['networkPermission'] and r['providerRequests']==0
assert r['success'] and r['status']=='passed' and len(r['cases'])==1 and r['cases'][0]['passed']
assert r['appVersion']==('1.0.35' if mode=='baseline135' else '1.0.36')
assert not any(marker in filtered for marker in ['FATAL EXCEPTION:','java.lang.OutOfMemoryError'])
assert 'ANR in kr.tong.sky' not in log
case=r['cases'][0]
for carrier,records,previous in [('KE',24,18),('OZ',1194,911)]:
 p=case[carrier]
 assert p['importedRecords']==records and p['previousPreserved']==previous
 assert p['newBrowserCalendars']==20 and p['totalDbRows']==records+21 and p['remoteRows']==records+20
 assert p['fingerprintsVerified'] and p['seedPreserved'] and p['outboxPending']==0
 assert p['outboxSchemaPresent']==(mode=='candidate136')
 assert r['serviceStarts'][carrier]['platformForeground'] and r['serviceStarts'][carrier]['realScannerLease']
 counts=case['workCounters']['regionRequests'][carrier]
 assert counts['GET']>=5 and counts['PUT']>=2
 if mode=='baseline135':assert counts['PUT']==22,counts
assert case['workCounters']['injectedPerRegionRequestMs']==100
assert r['maxConcurrentRegionHttpStreams']==1
out={'schema':1,'mode':mode,'api':33,'pid':pid,'heapBytes':r['runtimeMaxHeapBytes'],'workElapsedMs':r['workElapsedMs'],'sampledUsedBytes':r['sampledUsedBytes'],'unexpectedFatalCount':0,'anrCount':0,'case':case,'fixtureManifest':r['fixtures'],'scope':r['scope'],'readinessPump':r['readinessPump']}
(root/'verified-runtime.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
(root/'filtered-logcat.txt').write_text(filtered+'\n')
print(json.dumps({'mode':mode,'verified':True,'workElapsedMs':r['workElapsedMs'],'regionRequests':case['workCounters']['regionRequests']}))
