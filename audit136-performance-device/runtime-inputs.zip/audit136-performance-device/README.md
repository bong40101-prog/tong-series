# Offline native performance comparison

The two debug probes compile the exact production Java/assets from baseline1.0.35
and candidate1.0.36 with the same instrumentation and disposable debug signer.
Production code is not patched for the benchmark. The only manifest difference
is debug instrumentation and omission of INTERNET; the Air France process split
and normal192MiB heap remain in place.

Both actual foreground services process20 distinct current-month route calendars
each (10 city pairs in both directions). Normal parser, SQLite save, service
continuation, repository lease, GitHub Contents/blob transport, SHA/CAS and gzip
codec paths run. A local URL handler serves the same synthetic documents in both
phases:1,194 Asiana current records and911 previous records (about22MiB plain),
plus24 Korean Air current and18 previous records. Every original current,
previous and success clock is checked both in SQLite and the final shared file;
all40 new browser calendars must agree exactly between local/shared data.

The harness waits for the actual local Chromium fixture document, then calls
the real service tick. This is identical in both phases and removes the old
debug-only Korean Air12-second artificial fixture wait. It does not test
official form entry, same-page month reuse, provider responses or live account
compatibility. Those are separate checks. Each region HTTP request includes
exactly100ms of explicitly reported local injected latency. Recorded elapsed
time includes real local codec/storage and service pacing but cannot forecast
the user's live10-hour collection.

The runner asserts API33, emulator status, exact192MiB max heap, no INTERNET,
real foreground-service/scanner-lease ownership, serialized region streams and
no process FATAL/OOM/ANR. Candidate completion must leave its durable outbox
empty. Baseline expects22 region PUTs per carrier (claim+20 results+release);
candidate must use fewer, with the observed counts reported rather than a
promised80% elapsed-time reduction.

Build locally, after candidate production source is frozen:

```sh
python3 audit136-performance-device/build-probe.py --source /absolute/tong-sky-135 --sdk /absolute/android-sdk132 --out /absolute/baseline --label baseline135
python3 audit136-performance-device/build-probe.py --source /absolute/tong-sky-136 --sdk /absolute/android-sdk132 --out /absolute/candidate --label candidate136
```

Only the generated debug APKs and harness files are intended for the dedicated
audit branch. The release APK has no exported benchmark instrumentation.
