#!/usr/bin/env python3
"""Compare two verified independent native phases using identical synthetic inputs."""
import json,pathlib,sys
root=pathlib.Path(sys.argv[1]);before=json.loads((root/'baseline135/verified-runtime.json').read_text());after=json.loads((root/'candidate136/verified-runtime.json').read_text())
assert before['fixtureManifest']==after['fixtureManifest']
b=before['case']['workCounters'];a=after['case']['workCounters'];changes={}
for c in ['KE','OZ']:
 x=b['regionRequests'][c];y=a['regionRequests'][c]
 assert y['PUT']<x['PUT'],(c,x,y)
 changes[c]={'before':x,'after':y,'putReductionPercent':round((1-y['PUT']/x['PUT'])*100,2),'preservedOriginalRecords':after['case'][c]['importedRecords'],'preservedPrevious':after['case'][c]['previousPreserved'],'newBrowserCalendars':20}
out={'schema':1,'api':33,'heapBytes':192*1024*1024,'syntheticSameFixtures':True,'baselineVersion':'1.0.35','candidateVersion':'1.0.36','regionRequestChanges':changes,'beforeWorkElapsedMs':before['workElapsedMs'],'afterWorkElapsedMs':after['workElapsedMs'],'observedElapsedReductionPercent':round((1-after['workElapsedMs']/before['workElapsedMs'])*100,2),'beforeInjectedRegionLatencyMs':b['injectedRegionLatencyMs'],'afterInjectedRegionLatencyMs':a['injectedRegionLatencyMs'],'beforeWireReadBytes':b['wireReadBytes'],'afterWireReadBytes':a['wireReadBytes'],'beforeWireWriteBytes':b['wireWriteBytes'],'afterWireWriteBytes':a['wireWriteBytes'],'scope':'Actual native API33/192MiB offline services, local Chromium calendar parser and production GitHub transport/codec with100ms injected latency per region request.40 total calendars each phase. This excludes official page/form timing and cannot forecast the user live10-hour collection.'}
(root/'comparison.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(out,ensure_ascii=False))
